<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('activity_logs', function (Blueprint $table) {
            $table->id();
            $table->string('action'); // مثل ایجاد، ویرایش، حذف
            $table->string('user_name'); // مثلا Ali Rezaei
            $table->string('user_email')->nullable(); // ایمیل کاربر
            $table->text('description')->nullable(); // مثلا چه چیزی تغییر کرده
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('activity_logs');
    }
};
