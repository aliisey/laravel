<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Models\ActivityLog;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    // نمایش لیست کاربران
    /*
    public function index()
    {
        $users = User::all();
        return view('users.index', compact('users'));
    }

    // نمایش یک کاربر خاص
    public function show($id)
    {
        $user = User::findOrFail($id);
        return view('users.show', compact('user'));
    }

    // فرم ایجاد کاربر جدید
    public function create()
    {
        return view('users.create');
    }

    // ذخیره‌ی کاربر جدید در دیتابیس
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6'
        ]);

        User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
        ]);

        return redirect()->route('users.index')->with('success', 'کاربر با موفقیت ایجاد شد.');
    }


    // بروزرسانی اطلاعات کاربر
    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,'.$user->id,
            'password' => 'nullable|min:6'
        ]);

        $user->update([
            'name' => $request->name,
            'email' => $request->email,
            'password' => $request->password ? bcrypt($request->password) : $user->password,
        ]);

        return redirect()->route('users.index')->with('success', 'اطلاعات کاربر بروزرسانی شد.');
    }

    // حذف کاربر
    public function destroy($id)
    {
        $user = User::findOrFail($id);
        $user->delete();

        return redirect()->route('users.index')->with('success', 'کاربر حذف شد.');
    }

    public function edit($id) {
        $user = User::findOrFail($id);
        return view('users.edit', compact('user'));
    }

    ActivityLog::create([
        'action' => 'create',
        'user_name' => $user->name,
        'user_email' => $user->email,
        'description' => 'کاربر جدید ایجاد شد',
    ]);

    ActivityLog::create([
        'action' => 'update',
        'user_name' => $user->name,
        'user_email' => $user->email,
        'description' => 'کاربر ویرایش شد',
    ]);

    ActivityLog::create([
        'action' => 'delete',
        'user_name' => $user->name,
        'user_email' => $user->email,
        'description' => 'کاربر حذف شد',
    ]);

    public function logs(User $user)
{
    // فعلا برای تست یک نمونه ساده:
    return view('panel.user_logs', compact('user'));
}*/

public function edit($id)
{
    $user = User::findOrFail($id);
    return view('users.edit', compact('user'));
}

public function update(Request $request, $id)
{
    $user = User::findOrFail($id);

    // اعتبارسنجی ورودی‌ها
    $request->validate([
        'name' => 'required',
        'email' => 'required|email',
    ]);

    // آپدیت کاربر
    $user->update([
        'name' => $request->name,
        'email' => $request->email,
    ]);

    // ثبت لاگ
    ActivityLog::create([
        'action' => 'update',
        'user_name' => $user->name,
        'user_email' => $user->email,
        'description' => 'کاربر ویرایش شد',
    ]);

    return redirect()->route('users.index')->with('success', 'کاربر با موفقیت ویرایش شد.');
}

public function destroy($id)
{
    $user = User::findOrFail($id);
    $user->delete();

    // ثبت لاگ
    ActivityLog::create([
        'action' => 'delete',
        'user_name' => $user->name,
        'user_email' => $user->email,
        'description' => 'کاربر حذف شد',
    ]);

    return redirect()->route('users.index')->with('success', 'کاربر با موفقیت حذف شد.');
}

public function logs()
{
    $logs = \App\Models\ActivityLog::latest()->get();
    return view('logs.index', compact('logs'));
}

public function store(Request $request)
{
    $request->validate([
        'name' => 'required',
        'email' => 'required|email|unique:users',
        'password' => 'required|min:6', // اعتبارسنجی رمز عبور
    ]);

    $user = User::create([
        'name' => $request->name,
        'email' => $request->email,
        'password' => Hash::make($request->password), // هش کردن رمز
    ]);

    // لاگ ثبت کن
    ActivityLog::create([
        'action' => 'create',
        'user_name' => $user->name,
        'user_email' => $user->email,
        'description' => 'کاربر جدید ایجاد شد',
    ]);

    return redirect()->route('users.index')->with('success', 'کاربر با موفقیت اضافه شد.');
}


public function index()
{
    $users = User::all();
    return view('users.index', compact('users'));
}

    
}
