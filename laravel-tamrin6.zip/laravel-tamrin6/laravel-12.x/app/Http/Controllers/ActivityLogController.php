<?php

namespace App\Http\Controllers;

use App\Models\ActivityLog;

class ActivityLogController extends Controller
{
    public function index()
    {
        $logs = ActivityLog::latest()->paginate(20); // صفحه بندی 20 تایی
        return view('panel.activity_logs.index', compact('logs'));
    }
}
